"""Utility package for Streamlit app"""


